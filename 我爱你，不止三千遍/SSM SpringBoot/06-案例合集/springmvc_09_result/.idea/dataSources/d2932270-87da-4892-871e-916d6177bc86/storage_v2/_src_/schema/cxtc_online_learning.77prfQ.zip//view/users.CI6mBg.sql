create definer = root@localhost view users as
select `cxtc_online_learning`.`cxtc_account`.`account`  AS `account`,
       `cxtc_online_learning`.`cxtc_account`.`fraction` AS `fraction`,
       `cxtc_online_learning`.`cxtc_user`.`user_name`   AS `user_name`
from (`cxtc_online_learning`.`cxtc_account` join `cxtc_online_learning`.`cxtc_user`
      on ((`cxtc_online_learning`.`cxtc_account`.`user_id` = `cxtc_online_learning`.`cxtc_user`.`user_id`)));

-- comment on column users.account not supported: 账户名

-- comment on column users.fraction not supported: 用户积分

-- comment on column users.user_name not supported: 姓名

