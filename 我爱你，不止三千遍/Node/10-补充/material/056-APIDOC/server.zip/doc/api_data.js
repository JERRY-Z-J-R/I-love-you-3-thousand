define({ "api": [
  {
    "type": "post",
    "url": "/api/user",
    "title": "添加用户",
    "name": "addUser",
    "group": "usergroup",
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "age",
            "description": "<p>年龄</p>"
          },
          {
            "group": "Parameter",
            "type": "File",
            "optional": false,
            "field": "avatar",
            "description": "<p>头像</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    username : \"kerwin\",\n    password : \"123\",\n    age : 100,\n    avatar : File\n}",
          "type": "multipart/form-data"
        }
      ]
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ok",
            "description": "<p>标识成功字段</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    ok : 1\n}",
          "type": "type"
        }
      ]
    },
    "filename": "routes/users.js",
    "groupTitle": "usergroup"
  },
  {
    "type": "delete",
    "url": "/api/user/:id",
    "title": "删除用户",
    "name": "deleteUser",
    "group": "usergroup",
    "version": "1.0.0",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "ok",
            "description": "<p>标识成功字段</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n    ok : 1\n}",
          "type": "type"
        }
      ]
    },
    "filename": "routes/users.js",
    "groupTitle": "usergroup"
  }
] });
