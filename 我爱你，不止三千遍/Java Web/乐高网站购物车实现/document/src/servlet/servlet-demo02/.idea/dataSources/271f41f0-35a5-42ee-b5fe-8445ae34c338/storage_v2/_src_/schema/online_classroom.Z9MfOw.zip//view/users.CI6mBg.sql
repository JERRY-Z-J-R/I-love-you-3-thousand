create definer = root@localhost view users as
select `online_classroom`.`cxtc_account`.`account`  AS `account`,
       `online_classroom`.`cxtc_account`.`fraction` AS `fraction`,
       `online_classroom`.`cxtc_user`.`user_name`   AS `user_name`
from (`online_classroom`.`cxtc_account` join `online_classroom`.`cxtc_user`
      on ((`online_classroom`.`cxtc_account`.`user_id` = `online_classroom`.`cxtc_user`.`user_id`)));

-- comment on column users.account not supported: 账户名

-- comment on column users.fraction not supported: 用户积分

-- comment on column users.user_name not supported: 姓名

